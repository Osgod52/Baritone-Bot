package com.example.baritoneui.client;

import net.minecraft.class_310;
import net.minecraft.class_746;

/** Sends Baritone commands through the normal client chat pipeline. */
public final class BaritoneCommandSender {
    private static final String PREFIX = "#";

    private BaritoneCommandSender() {}

    public static void send(String command) {
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null) return;

        String fullMessage = PREFIX + command.trim();
        player.field_3944.method_45729(fullMessage);
    }

    public static void send(String command, String... args) {
        StringBuilder sb = new StringBuilder(command);
        for (String arg : args) {
            if (arg == null || arg.isBlank()) continue;
            sb.append(' ').append(arg.trim());
        }
        send(sb.toString());
    }
}
