package com.example.baritoneui.client;

import com.example.baritoneui.client.gui.BaritoneUIScreen;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class KeyBindings {
    private static final String CATEGORY = "key.categories.baritoneui";

    public static final class_304 OPEN_UI = new class_304(
            "key.baritoneui.open",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_B,
            CATEGORY
    );

    private KeyBindings() {}

    public static void tick() {
        class_310 mc = class_310.method_1551();
        while (OPEN_UI.method_1436()) {
            if (mc.field_1755 == null) {
                mc.method_1507(new BaritoneUIScreen());
            }
        }
    }
}
