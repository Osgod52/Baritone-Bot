package com.example.baritoneui.client.gui;

import com.example.baritoneui.client.BaritoneCommandSender;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_6379;

/**
 * A tabbed control panel for Baritone. Every button on every tab ultimately
 * calls BaritoneCommandSender.send(...), which just sends the equivalent
 * "#command" chat line - nothing here talks to Baritone's Java API.
 * <p>
 * Layout is designed at a fixed "base" size (BASE_PANEL_WIDTH x
 * BASE_PANEL_HEIGHT, as if scale == 1) and then every coordinate is passed
 * through x()/y()/s() to convert it into real pixels for whatever "scale"
 * ends up being. This keeps the whole panel - and everything inside it -
 * shrinking together so it always fits the screen's actual GUI space, which
 * can be much smaller than the window resolution suggests if the player has
 * a high GUI Scale set (Options > Video Settings).
 */
public class BaritoneUIScreen extends class_437 {

    private enum Tab {
        MOVEMENT("Movement"),
        MINING("Mining"),
        BUILDING("Building"),
        WAYPOINTS("Waypoints"),
        SETTINGS("Settings"),
        CONSOLE("Console");

        final String label;
        Tab(String label) { this.label = label; }
    }

    // Keeps the last commands visible even after closing/reopening the screen.
    private static final LinkedList<String> HISTORY = new LinkedList<>();
    private static final int HISTORY_MAX = 4;

    // Design-time layout size at scale == 1. Every number used below in
    // buildTabContent()/init() is expressed relative to this box, then run
    // through x()/y()/s() to get real, on-screen pixels.
    private static final int BASE_PANEL_WIDTH = 360;
    private static final int BASE_PANEL_HEIGHT = 300;

    private Tab currentTab = Tab.MOVEMENT;

    private float scale = 1f;
    private int panelWidth, panelHeight;
    private int panelX, panelY;

    // Text fields kept as fields so we can read them across renders.
    private class_342 gotoX, gotoY, gotoZ;
    private class_342 followEntity;
    private class_342 thiswayDistance;
    private class_342 mineBlocks;
    private class_342 farmRadius;
    private class_342 buildSchematic;
    private class_342 tunnelH, tunnelW, tunnelD;
    private class_342 selFillBlock;
    private class_342 waypointName;
    private class_342 consoleInput;

    private final List<class_342> activeFields = new ArrayList<>();
    // Widgets created per-tab that need to be torn down on tab switch.
    private final List<class_364> rebuildable = new ArrayList<>();

    public BaritoneUIScreen() {
        super(class_2561.method_43470("Baritone UI"));
    }

    @Override
    protected void method_25426() {
        // Shrink the whole panel to fit whatever GUI space is actually
        // available. On a normal setup this is 1.0 (no shrinking at all).
        int margin = 20;
        float scaleW = (this.field_22789 - margin) / (float) BASE_PANEL_WIDTH;
        float scaleH = (this.field_22790 - margin) / (float) BASE_PANEL_HEIGHT;
        scale = Math.min(1f, Math.min(scaleW, scaleH));
        // Don't shrink so far that text/buttons become unusable. If your
        // screen genuinely can't fit even this, lower Minecraft's GUI Scale
        // (Options > Video Settings > GUI Scale) for more room.
        scale = Math.max(scale, 0.5f);

        panelWidth = Math.round(BASE_PANEL_WIDTH * scale);
        panelHeight = Math.round(BASE_PANEL_HEIGHT * scale);
        panelX = (this.field_22789 - panelWidth) / 2;
        panelY = (this.field_22790 - panelHeight) / 2;

        // --- Tab bar ---
        int tabCount = Tab.values().length;
        int tabWidthBase = BASE_PANEL_WIDTH / tabCount;
        int txBase = 0;
        for (Tab tab : Tab.values()) {
            int fxBase = txBase;
            this.method_37063(class_4185.method_46430(class_2561.method_43470(tab.label), b -> switchTab(tab))
                    .method_46434(x(fxBase), y(0), s(tabWidthBase - 2), s(20))
                    .method_46431());
            txBase += tabWidthBase;
        }

        // --- Global controls (always visible, bottom of panel) ---
        int bottomYBase = BASE_PANEL_HEIGHT - 24;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Pause"), b -> send("pause"))
                .method_46434(x(0), y(bottomYBase), s(80), s(20)).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Resume"), b -> send("resume"))
                .method_46434(x(84), y(bottomYBase), s(80), s(20)).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Cancel/Stop"), b -> send("cancel"))
                .method_46434(x(168), y(bottomYBase), s(100), s(20)).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Close"), b -> this.method_25419())
                .method_46434(x(BASE_PANEL_WIDTH - 60), y(bottomYBase), s(60), s(20)).method_46431());

        buildTabContent();
    }

    // --- base-unit -> real-pixel conversion -------------------------------
    private int x(int baseOffsetFromPanel) { return panelX + Math.round(baseOffsetFromPanel * scale); }
    private int y(int baseOffsetFromPanel) { return panelY + Math.round(baseOffsetFromPanel * scale); }
    private int s(int baseSize) { return Math.max(1, Math.round(baseSize * scale)); }

    private void switchTab(Tab tab) {
        this.currentTab = tab;
        // Remove old dynamic widgets and rebuild for the new tab.
        for (class_342 box : activeFields) this.method_37066(box);
        activeFields.clear();
        rebuildable.forEach(this::method_37066);
        rebuildable.clear();
        buildTabContent();
    }

    private <T extends class_364 & class_4068 & class_6379> T addTabWidget(T widget) {
        this.method_37063(widget);
        rebuildable.add(widget);
        return widget;
    }

    /**
     * xBase/yBase/wBase are in the same base units as everything else in
     * buildTabContent() - they get converted to real pixels here.
     * <p>
     * NOTE: vanilla TextFieldWidget does not clip hint text to the box's width - a
     * hint longer than the box just overflows visually into whatever is
     * drawn to its right. Keep hints short enough to actually fit inside
     * width {@code wBase} (roughly wBase/7 characters), or widen the box /
     * move the next widget further right.
     */
    private class_342 field(int xBase, int yBase, int wBase, String hint) {
        class_342 box = new class_342(this.field_22793, x(xBase), y(yBase), s(wBase), s(18), class_2561.method_43470(hint));
        box.method_47404(class_2561.method_43470(hint));
        box.method_1880(64);
        addTabWidget(box);
        activeFields.add(box);
        return box;
    }

    /** Shorthand for a button whose bounds are given in base units. */
    private class_4185.class_7840 btn(String label, class_4185.class_4241 onPress, int xBase, int yBase, int wBase, int hBase) {
        return class_4185.method_46430(class_2561.method_43470(label), onPress)
                .method_46434(x(xBase), y(yBase), s(wBase), s(hBase));
    }

    private void buildTabContent() {
        int contentY = 26; // base-unit offset from panel top
        int col1 = 8;      // base-unit offset from panel left

        switch (currentTab) {
            case MOVEMENT -> {
                gotoX = field(col1, contentY + 18, 50, "x");
                gotoY = field(col1 + 54, contentY + 18, 50, "y");
                gotoZ = field(col1 + 108, contentY + 18, 50, "z");
                addTabWidget(btn("Goto XYZ", b ->
                                send("goto " + gotoX.method_1882() + " " + gotoY.method_1882() + " " + gotoZ.method_1882()),
                        col1 + 164, contentY + 18, 100, 18).method_46431());

                addTabWidget(btn("Path (to cursor)", b -> send("path"), col1, contentY + 42, 150, 18).method_46431());
                addTabWidget(btn("Come to me", b -> send("come"), col1 + 154, contentY + 42, 110, 18).method_46431());

                followEntity = field(col1, contentY + 68, 120, "player/entity");
                addTabWidget(btn("Follow", b -> send("follow " + followEntity.method_1882()),
                        col1 + 124, contentY + 68, 80, 18).method_46431());
                addTabWidget(btn("Follow players", b -> send("follow players"),
                        col1 + 208, contentY + 68, 130, 18).method_46431());

                thiswayDistance = field(col1, contentY + 94, 80, "blocks");
                addTabWidget(btn("This way", b -> send("thisway " + thiswayDistance.method_1882()),
                        col1 + 84, contentY + 94, 90, 18).method_46431());
                addTabWidget(btn("Explore", b -> send("explore"), col1 + 178, contentY + 94, 90, 18).method_46431());

                addTabWidget(btn("Top (surface up)", b -> send("top"), col1, contentY + 120, 150, 18).method_46431());
                addTabWidget(btn("Surface", b -> send("surface"), col1 + 154, contentY + 120, 110, 18).method_46431());
                addTabWidget(btn("Invert goal", b -> send("invert"), col1, contentY + 146, 264, 18).method_46431());
            }
            case MINING -> {
                mineBlocks = field(col1, contentY + 18, 180, "blocks (space sep)");
                addTabWidget(btn("Mine", b -> send("mine " + mineBlocks.method_1882()),
                        col1 + 184, contentY + 18, 80, 18).method_46431());

                farmRadius = field(col1, contentY + 44, 80, "radius");
                addTabWidget(btn("Farm", b -> {
                            String r = farmRadius.method_1882();
                            send(r.isBlank() ? "farm" : "farm " + r);
                        }, col1 + 84, contentY + 44, 90, 18).method_46431());
                addTabWidget(btn("Stop farming", b -> send("cancel"), col1 + 178, contentY + 44, 90, 18).method_46431());

                addTabWidget(btn("Blacklist current mine target", b -> send("blacklist"),
                        col1, contentY + 70, 264, 18).method_46431());
                addTabWidget(btn("Click block to select mine target", b -> send("click"),
                        col1, contentY + 96, 264, 18).method_46431());
            }
            case BUILDING -> {
                buildSchematic = field(col1, contentY + 18, 180, "schematic file name");
                addTabWidget(btn("Build", b -> send("build " + buildSchematic.method_1882()),
                        col1 + 184, contentY + 18, 80, 18).method_46431());

                tunnelH = field(col1, contentY + 44, 50, "height");
                tunnelW = field(col1 + 54, contentY + 44, 50, "width");
                tunnelD = field(col1 + 108, contentY + 44, 50, "depth");
                addTabWidget(btn("Tunnel", b -> {
                            String h = tunnelH.method_1882(), w = tunnelW.method_1882(), d = tunnelD.method_1882();
                            StringBuilder cmd = new StringBuilder("tunnel");
                            if (!h.isBlank()) cmd.append(' ').append(h);
                            if (!w.isBlank()) cmd.append(' ').append(w);
                            if (!d.isBlank()) cmd.append(' ').append(d);
                            send(cmd.toString());
                        }, col1 + 164, contentY + 44, 100, 18).method_46431());

                addTabWidget(btn("Sel Pos1", b -> send("sel pos1"), col1, contentY + 70, 84, 18).method_46431());
                addTabWidget(btn("Sel Pos2", b -> send("sel pos2"), col1 + 88, contentY + 70, 84, 18).method_46431());
                addTabWidget(btn("Sel Clear", b -> send("sel clear"), col1 + 176, contentY + 70, 88, 18).method_46431());

                selFillBlock = field(col1, contentY + 96, 150, "block to fill with");
                addTabWidget(btn("Sel Fill", b -> send("sel fill " + selFillBlock.method_1882()),
                        col1 + 154, contentY + 96, 110, 18).method_46431());

                addTabWidget(btn("Sel Copy", b -> send("sel copy"), col1, contentY + 122, 130, 18).method_46431());
                addTabWidget(btn("Sel Paste", b -> send("sel paste"), col1 + 134, contentY + 122, 130, 18).method_46431());
            }
            case WAYPOINTS -> {
                addTabWidget(btn("Set Home Here", b -> send("sethome"), col1, contentY + 18, 130, 18).method_46431());
                addTabWidget(btn("Goto Home", b -> send("home"), col1 + 134, contentY + 18, 130, 18).method_46431());

                waypointName = field(col1, contentY + 44, 150, "waypoint name");
                addTabWidget(btn("Save", b -> send("waypoints save " + waypointName.method_1882()),
                        col1 + 154, contentY + 44, 55, 18).method_46431());
                addTabWidget(btn("Goto", b -> send("waypoints goto " + waypointName.method_1882()),
                        col1 + 211, contentY + 44, 53, 18).method_46431());

                addTabWidget(btn("List waypoints", b -> send("waypoints list"), col1, contentY + 70, 130, 18).method_46431());
                addTabWidget(btn("Clear all waypoints", b -> send("waypoints clear"),
                        col1 + 134, contentY + 70, 130, 18).method_46431());
            }
            case SETTINGS -> {
                String[] settings = {
                        "allowBreak", "allowPlace", "allowSprint", "allowInventory",
                        "allowParkour", "allowJumpAt", "freeLook", "legitMine"
                };
                int i = 0;
                for (String setting : settings) {
                    int row = i / 2;
                    int colOffset = (i % 2) * 134;
                    addTabWidget(btn("Toggle: " + setting, b -> send("set " + setting),
                            col1 + colOffset, contentY + 18 + row * 22, 130, 18).method_46431());
                    i++;
                }
                addTabWidget(btn("Show all settings (#set)", b -> send("set"),
                        col1, contentY + 18 + ((settings.length / 2) + 1) * 22, 264, 18).method_46431());
            }
            case CONSOLE -> {
                consoleInput = field(col1, contentY + 18, 200, "raw command, no # needed");
                addTabWidget(btn("Send", b -> {
                            String v = consoleInput.method_1882();
                            if (!v.isBlank()) {
                                send(v);
                                consoleInput.method_1852("");
                            }
                        }, col1 + 204, contentY + 18, 60, 18).method_46431());
                addTabWidget(btn("Help", b -> send("help"), col1, contentY + 44, 84, 18).method_46431());
                addTabWidget(btn("Version", b -> send("version"), col1 + 88, contentY + 44, 84, 18).method_46431());
                addTabWidget(btn("Render", b -> send("render"), col1 + 176, contentY + 44, 88, 18).method_46431());
            }
        }
    }

    private void send(String command) {
        if (command == null || command.isBlank()) return;
        BaritoneCommandSender.send(command);
        HISTORY.addFirst("#" + command.trim());
        while (HISTORY.size() > HISTORY_MAX) HISTORY.removeLast();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);

        graphics.method_25294(panelX - 4, panelY - 4, panelX + panelWidth + 4, panelY + panelHeight + 4, 0xB0101010);

        super.method_25394(graphics, mouseX, mouseY, delta);

        // History log sits in its own reserved strip between the tallest
        // tab's content and the bottom button bar.
        int histYBase = BASE_PANEL_HEIGHT - 70;
        int lineGapBase = 10;
        int cutoffYBase = BASE_PANEL_HEIGHT - 32;

        graphics.method_51433(this.field_22793, "Last sent:", x(4), y(histYBase - 12), 0xAAAAAA, false);
        int lineBase = histYBase;
        for (String line : HISTORY) {
            graphics.method_51433(this.field_22793, line, x(4), y(lineBase), 0x55FF55, false);
            lineBase += lineGapBase;
            if (lineBase > cutoffYBase) break;
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
