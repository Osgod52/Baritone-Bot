package com.example.baritoneui;

/**
 * Common marker for the Fabric client mod. The actual entrypoint is client-only
 * because this mod is a GUI and chat-command helper.
 */
public final class BaritoneUIMod {
    public static final String MOD_ID = "baritoneui";

    private BaritoneUIMod() {}
}
